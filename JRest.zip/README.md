# JRest
Light-weight REST API library for java
